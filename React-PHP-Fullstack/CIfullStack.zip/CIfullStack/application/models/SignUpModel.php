<?php
/**
 * 
 */
class SignUpModel extends CI_Model
{
	function insertUserData($id,$name,$gender,$dob,$address,$contact,$email,$password,$language,$country){

		$tuple=array(
		'name'=>$name,
		'gender'=>$gender,
		'dob'=>$dob,
		'address'=>$address,
		'contact'=>$contact,
		'email'=>$email,
		'password'=>$password,
		'language'=>$language,
		'country'=>$country,
		 );
		$this->db->where('id', $id);
		return $this->db->update('signup', $tuple);
		// return($this->db->insert('signup', $tuple));
	}

	function editUserData($id,$name,$gender,$dob,$address,$contact,$email,$language,$country){

		$tuple=array(
		'name'=>$name,
		'gender'=>$gender,
		'dob'=>$dob,
		'address'=>$address,
		'contact'=>$contact,
		'email'=>$email,
		'language'=>$language,
		'country'=>$country,
		 );
		$this->db->where('id', $id);
		return $this->db->update('signup', $tuple);
		// return($this->db->insert('signup', $tuple));
	}

	function uploadUserFile($myFiles){
		$tuple=array('id'=>'',
		'files'=>$myFiles);
		$this->db->insert('signup', $tuple);
		$insert_id = $this->db->insert_id();
		return $insert_id;
		// return ($this->db->insert('tbl_file', $tuple));

	}

	function editUserFile($myFiles, $id){
		$tuple=array('files'=>$myFiles);
		$this->db->where('id', $id);
		return $this->db->update('signup', $tuple);
		// return ($this->db->insert('tbl_file', $tuple));

	}

	function getUploadFile(){
		$qry = $this->db->query("SELECT * FROM signup") ;
		return $qry->result();
	}

	function getAllRecords(){
		$qry = $this->db->query("SELECT * FROM signup");
		return $qry->result();
	}

	function getRecordByID($id){
		if($id != ''){
			$this->db->where('id', $id);
			$qry = $this->db->get('signup');
			return $qry->result();	
		}
		else{
			$qry = $this->db->query("SELECT * FROM signup");
			return $qry->result();
		}
		
	}

	function deleteRecordByID($id){
		$this->db->where('id', $id);
		$qry = $this->db->delete('signup');
		if($qry){
			return true;
		}
		else{
			return false;
		}
	}
}
?>