<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS, DELETE, PUT");
header("Content-Type: application/json; charset=UTF-8");
header('Access-Control-Allow-Credentials', 'true');
header("Access-Control-Allow-Headers: Content-Type, Origin, Accept, Authorization, X-Requested-With");
// header("HTTP/1.1 200 OK");

/**
 * 
 */
class SignUpController extends CI_Controller
{
	
	function __construct()
	{

		parent::__construct();
		$this->load->model('SignUpModel');
        
	}

	function test(){
		echo "string";
	}

	function insertData(){

		$data = json_decode(file_get_contents('php://input'));
        
		$insertUser = $this->SignUpModel->insertUserData($data->id, $data->name, $data->gender, $data->dob, $data->address, $data->contact, $data->email, md5($data->password), implode(",",$data->language), $data->country);

        if($insertUser){        
            echo json_encode(["success"=>"1","msg"=>"User Inserted."]);
        }
        else{
            echo json_encode(["success"=>"0","msg"=>"User Not Inserted!"]);
        }
	}

    function editData(){

        $data = json_decode(file_get_contents('php://input'));
        $editUser = $this->SignUpModel->editUserData($data->id, $data->name, $data->gender, $data->dob, $data->address, $data->contact, $data->email, implode(",",$data->language), $data->country);

        if($editUser){        
            echo json_encode(["success"=>"1","msg"=>"User Updated."]);
        }
        else{
            echo json_encode(["success"=>"0","msg"=>"User Not Updated!"]);
        }
    }


	function uploadFile(){

		$flag = 0;
        $err='';
        $config = array(
            'upload_path'   => './uploads/',
            'allowed_types' => 'jpg|gif|png',
            'overwrite'     => 1,                       
        );

        $this->load->library('upload', $config);

        $files = $_FILES;
        // print_r(implode(",",$files['files']['name']));
        $myFiles = implode(",",$files['files']['name']);

    	for($i=0; $i< count($files['files']['name']); $i++)
    	{           
        	$_FILES['files']['name']= $files['files']['name'][$i];
        	$_FILES['files']['type']= $files['files']['type'][$i];
        	$_FILES['files']['tmp_name']= $files['files']['tmp_name'][$i];
        	$_FILES['files']['error']= $files['files']['error'][$i];
        	$_FILES['files']['size']= $files['files']['size'][$i];    

        	$this->upload->initialize($config);

        	if($this->upload->do_upload('files')){
        		$flag=0;
        		$insertFile = $this->SignUpModel->uploadUserFile($files['files']['name'][$i]);  
        	}
        	else{
        		$flag=1;
        		// $err=$this->upload->display_errors();
        	}
    	}

        if($flag==0){     
            echo json_encode(["success"=>"1","msg"=>"File Uploaded","id"=>$insertFile]);
        }
        else{
            echo json_encode(["success"=>"0","msg"=>"File type not allowed! Allowed types are jpg,gif,png"]);
        }
        
	}

    function editUploadFile(){

        $flag = 0;
        $err='';
        $config = array(
            'upload_path'   => './uploads/',
            'allowed_types' => 'jpg|gif|png',
            'overwrite'     => 1,                       
        );

        $this->load->library('upload', $config);

        $files = $_FILES;
        
        $myFiles = implode(",",$files['files']['name']);

        for($i=0; $i< count($files['files']['name']); $i++)
        {           
            $_FILES['files']['name']= $files['files']['name'][$i];
            $_FILES['files']['type']= $files['files']['type'][$i];
            $_FILES['files']['tmp_name']= $files['files']['tmp_name'][$i];
            $_FILES['files']['error']= $files['files']['error'][$i];
            $_FILES['files']['size']= $files['files']['size'][$i];    

            $this->upload->initialize($config);

            if($this->upload->do_upload('files')){
                $flag=0;
                $editFile = $this->SignUpModel->editUserFile($files['files']['name'][$i], $_POST['id']);
            }
            else{
                $flag=1;
                // $err=$this->upload->display_errors();
            }
        }

        if($flag==0){     
            echo json_encode(["success"=>"1","msg"=>"File Updated"]);
        }
        else{
            echo json_encode(["success"=>"0","msg"=>"File type not allowed! Allowed types are jpg,gif,png"]);
        }
        
    }

	function getFile(){
		$file_data=$this->SignUpModel->getUploadFile();
		
		echo json_encode(["success"=>"1", "fileData"=>$file_data]);
	}

    function getAllData(){
        $data = $this->SignUpModel->getAllRecords();
        if($data){
            echo json_encode(["success"=>"1","msg"=>"All records found","userdata"=>$data]);
        }
        else{
            echo json_encode(["success"=>"0","msg"=>"No records found"]);
        }
    }

    function getDataByID(){
        $id = json_decode(file_get_contents('php://input'));
        $data = $this->SignUpModel->getRecordByID($id->userID);
        if($data){
            echo json_encode(["success"=>"1","msg"=>"User records found","userdata"=>$data]);
        }
        else{
            echo json_encode(["success"=>"0","msg"=>"No records found"]);
        }

    }

    function deleteUser(){
        $id = json_decode(file_get_contents('php://input'));
        $data = $this->SignUpModel->deleteRecordByID($id->userID);
        if($data){
            echo json_encode(["success"=>"1","msg"=>"User records deleted"]);
        }
        else{
            echo json_encode(["success"=>"0","msg"=>"No records found"]);
        }
    }
}
?>